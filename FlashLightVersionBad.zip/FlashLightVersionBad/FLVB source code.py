"""
Copyright 2018 The Snazzmaster

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated
documentation files (the "Software"), to deal in the Software without restriction, including without limitation the
rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software,
and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"""

"""Special thanks to Toast Engineer, creator of the game INJECTION
(which you can download here https://schilcote.itch.io/injection) who walked me through a long e-mail conversation
on how to turn pygame/pygcurse games into an exe file."""

import pygame
import pygcurse
import random
import sys
from math import sqrt
import time

_WIDTH = 100
_HEIGHT = 50

allchars = "`1234567890-=~!@#$%^&*()_+qwertyuiop[]\\asdfghjkl;'zxcvbnm,./QWERTYUIOP{}|ASDFGHJKL:\"ZXCVBNM<>?"
pygame.init()
font = pygame.font.Font("FSEX300.ttf", 10)
win = pygcurse.PygcurseWindow(_WIDTH, _HEIGHT, "Flash Light", font=font)

win.autoupdate = False
pygame.mouse.set_visible(False)

cellx = 0
celly = 0
keys = pygame.key.get_pressed()
spoopies = []
score = 0
spotlighttime = 0
red = [random.randint(0, _WIDTH-1), random.randint(0, _HEIGHT - 2)]


def random_spoopies():
    for i in range(random.randint(int((_WIDTH * _HEIGHT) * 0.4), int((_WIDTH * _HEIGHT) * 0.6))):
        spoopies.append([random.randint(0 ,_WIDTH), random.randint(0, _HEIGHT)])


def all_spoopies():
    for i in range(0,_WIDTH):
        for n in range(0,_HEIGHT):
            spoopies.append([i, n])


def dist(x1,y1,x2,y2):
    num = sqrt(((x1 - x2) ** 2) + ((y1 - y2) ** 2))
    return num


def winner():
    win.fill(fgcolor="black")
    win.putchars(" \\ / /\"\\ | |   \\/\\/  \"|\" |\\ | |", x=int(_WIDTH + 6), y=int(_HEIGHT / 2 - 3), fgcolor="white")
    win.putchars("  |  \\_/ \\_/   \\/\\/  _|_ | \\| o", x=int(_WIDTH + 6), y=int(_HEIGHT / 2 - 2), fgcolor="white")
    win.putchars(" Your score: " + str(score), x=int(_WIDTH + 6), y=int(_HEIGHT / 2), fgcolor="white")
    win.putchars(" To play again, please press any key", x=int(_WIDTH + 6), y=int(_HEIGHT / 2 + 2), fgcolor="white")
    win.update()


all_spoopies()
win.putchars("Press any key to start", x=15, y=15,fgcolor="white")
win.update()
pygcurse.waitforkeypress()
while True:
    win.fill(fgcolor="black")
    for i in range(len(spoopies)):
        ogb = int(dist(spoopies[i][0], spoopies[i][1], cellx, celly))
        b = ogb

        #_CHAR = allchars[random.randint(0, len(allchars) - 1)]
        _CHAR = chr(random.randint(1,255))

        if b > 10:
            b = 10
        if b < 10:
            b = (b * 25) % 256
            b = 255 - b
            color = pygame.Color(0, 0, b)
            if (spoopies[i][0] == red[0]) and (spoopies[i][1] == red[1]):
                color = pygame.Color(b,0,0)
            win.putchars(_CHAR, x=spoopies[i][0], y=spoopies[i][1], fgcolor=color)
            win.putchars("X", x=cellx, y=celly, fgcolor="green")
            if (cellx == red[0]) and (celly == red[1]):
                spotlighttime += 1

    for event in pygame.event.get():
        if event.type == pygame.locals.QUIT:
            pygame.quit()
            sys.exit()
        if event.type == pygame.locals.MOUSEMOTION:
            cellx, celly = win.getcoordinatesatpixel(event.pos)
    win.putchars("Score: " + str(score), fgcolor="white", x=0,y=0)
    """
    for i in range(1,255):
        win.pygprint(chr(i),x=i,y=1,fgcolor="white")
    """
    score += 1
    if spotlighttime >= 50:
        winner()
        pygcurse.waitforkeypress()
        cellx = 0
        celly = 0
        keys = pygame.key.get_pressed()
        spoopies = []
        score = 0
        spotlighttime = 0
        red = [random.randint(0, _WIDTH-1), random.randint(0, _HEIGHT - 2)]
        all_spoopies()
    win.update()




